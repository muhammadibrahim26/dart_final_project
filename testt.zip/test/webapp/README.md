An absolute bare-bones web app.
